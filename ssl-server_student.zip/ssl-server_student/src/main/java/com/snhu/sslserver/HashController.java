package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@RestController
public class HashController {

    @GetMapping("/hash")
    public String checksum() throws Exception {
        String data = "Carlton Jackson | Artemis-Checksum-2025 | TX";
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));

        StringBuilder sb = new StringBuilder(hash.length * 2);
        for (byte b : hash) {
            String h = Integer.toHexString(b & 0xff);
            if (h.length() == 1) sb.append('0');
            sb.append(h);
        }
        return "<p>data: " + data + "</p>"
             + "<p>algorithm: SHA-256</p>"
             + "<p>checksum: " + sb + "</p>";
    }
}
